# m1-resolucao-atividades-sprint6
